import "%modules%/hero/hero.js";
import "%modules%/box/box.js";
import "%modules%/slider/slider.js";
